# Linux Server Automation Using Ansible

A practical infrastructure automation project for managing multiple RHEL-compatible Linux servers from one Ansible control node.

## Project overview

This project demonstrates how to automate common Linux administration tasks across multiple managed servers:

- Inventory and SSH connectivity
- User and group management
- Package installation
- Apache HTTPD deployment
- Firewall configuration
- Service management with handlers
- Reusable Ansible roles
- Configuration validation

**Target platforms:** Rocky Linux 9 / RHEL 9 (adaptable to compatible distributions)  
**Automation tool:** Ansible Core  
**Recommended lab:** VMware Workstation with one controller and two managed nodes

> Use this project only on systems you own or are explicitly authorized to administer.

## Architecture

```text
                  SSH
+-----------------------------+
| Ansible Control Node        |
| controlnode                 |
| Ansible Core                |
| Inventory + Playbooks       |
+--------------+--------------+
               |
       +-------+-------+
       |               |
       v               v
+--------------+  +--------------+
| Managed Node |  | Managed Node |
| node1        |  | node2        |
| Rocky/RHEL 9 |  | Rocky/RHEL 9 |
+--------------+  +--------------+
```

## Repository structure

```text
linux-server-automation-ansible/
├── ansible.cfg
├── requirements.yml
├── inventory/
│   ├── hosts.ini
│   └── group_vars/
│       └── all.yml
├── playbooks/
│   ├── ping.yml
│   ├── users.yml
│   ├── packages.yml
│   ├── webserver.yml
│   └── site.yml
├── roles/
│   ├── common/
│   │   └── tasks/main.yml
│   ├── users/
│   │   ├── defaults/main.yml
│   │   └── tasks/main.yml
│   └── webserver/
│       ├── handlers/main.yml
│       ├── tasks/main.yml
│       └── templates/index.html.j2
├── .gitignore
└── LICENSE
```

## 1. Lab prerequisites

Create three VMs:

| VM | Hostname | Suggested RAM | Suggested disk | Purpose |
|---|---|---:|---:|---|
| Controller | controlnode | 2 GB | 25 GB | Runs Ansible |
| Managed node 1 | node1 | 2 GB | 20 GB | Target server |
| Managed node 2 | node2 | 2 GB | 20 GB | Target server |

All VMs must have network connectivity to each other. The controller must be able to SSH to both managed nodes.

Example addresses (replace these with your actual addresses):

| Host | Example IP |
|---|---|
| controlnode | 192.168.100.10 |
| node1 | 192.168.100.11 |
| node2 | 192.168.100.12 |

## 2. Install Ansible on the controller

On Rocky Linux 9, install Ansible Core using the repositories available to your environment:

```bash
sudo dnf install -y ansible-core
ansible --version
```

If the package is unavailable, verify that your enabled repositories are configured correctly before proceeding. RHEL systems may require valid subscription or repository access.

## 3. Prepare the managed nodes

On each managed node:

```bash
sudo dnf install -y python3 openssh-server
sudo systemctl enable --now sshd
sudo useradd -m ansible
sudo passwd ansible
```

Grant the automation account passwordless sudo for this lab:

```bash
echo 'ansible ALL=(ALL) NOPASSWD: ALL' | sudo tee /etc/sudoers.d/ansible
sudo chmod 0440 /etc/sudoers.d/ansible
sudo visudo -cf /etc/sudoers.d/ansible
```

For production, use a least-privilege sudo policy rather than unrestricted sudo.

## 4. Configure SSH key authentication

On the controller, become the automation user and generate a key:

```bash
sudo -iu ansible
ssh-keygen -t ed25519
ssh-copy-id ansible@192.168.100.11
ssh-copy-id ansible@192.168.100.12
```

Test both connections:

```bash
ssh ansible@node1
ssh ansible@node2
```

Do not upload private SSH keys, passwords, or real host secrets to GitHub.

## 5. Configure inventory

Edit `inventory/hosts.ini` and replace the example addresses:

```ini
[linux_servers]
node1 ansible_host=192.168.100.11
node2 ansible_host=192.168.100.12

[linux_servers:vars]
ansible_user=ansible
ansible_become=true
ansible_python_interpreter=/usr/bin/python3
```

Test connectivity:

```bash
ansible linux_servers -m ping
```

Expected result: both hosts return `pong`.

The webserver role uses the `ansible.posix.firewalld` module. Install its collection on the controller before running the webserver playbook:

```bash
ansible-galaxy collection install ansible.posix
```

## 6. Run the playbooks

From the repository root:

```bash
# Test connectivity
ansible-playbook playbooks/ping.yml

# Create example administration users and groups
ansible-playbook playbooks/users.yml

# Install common administration packages
ansible-playbook playbooks/packages.yml

# Deploy Apache HTTPD
ansible-playbook playbooks/webserver.yml

# Run the complete configuration
ansible-playbook playbooks/site.yml
```

Check the web server from a browser or with curl:

```bash
curl http://192.168.100.11
curl http://192.168.100.12
```

If HTTP access is blocked, check the host firewall, VMware network mode, and any upstream firewall rules.

## 7. Verify the result

```bash
ansible linux_servers -m command -a "hostname"
ansible linux_servers -m command -a "systemctl is-active httpd"
ansible linux_servers -m command -a "rpm -q httpd"
```

Run the playbooks a second time. A well-designed idempotent playbook should report no unnecessary changes.

## 8. Customization

Before running, review these variables:

- `inventory/group_vars/all.yml`
- `roles/users/defaults/main.yml`

Change the sample user names and package list to suit your lab. The sample administration account is intentionally not given a password by the playbook.

## Learning outcomes

After completing this project, you should be able to explain:

1. Control node vs. managed node
2. Inventory and host/group variables
3. SSH key-based authentication
4. Privilege escalation with `become`
5. Ansible modules and idempotency
6. Playbooks, roles, templates, and handlers
7. Service and firewall automation
8. Troubleshooting unreachable hosts and failed tasks

## Suggested GitHub screenshots

Add your own screenshots under a `screenshots/` directory:

- Successful `ansible linux_servers -m ping`
- Playbook execution recap
- Apache test page from node1 and node2
- `systemctl status httpd`
- Second playbook run showing idempotency

Do not include screenshots containing passwords, private keys, public IPs you do not intend to disclose, or sensitive infrastructure details.

## Resume description

**Linux Server Automation Using Ansible**  
Designed and implemented a multi-node Linux automation lab using Ansible. Configured SSH key-based access, inventory management, user and group administration, package installation, Apache deployment, and firewall rules using reusable roles, variables, templates, and handlers.

## License

This project is released under the MIT License. See `LICENSE`.
